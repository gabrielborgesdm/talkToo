# Talk Too
Software de bate-papo implementado com bootstrap e Ajax
